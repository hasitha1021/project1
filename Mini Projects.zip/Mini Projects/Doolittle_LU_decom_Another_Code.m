clc
clear all
close all

%%%% This is method we learn from tutorial.......%%%%

%%% QUESTION C %%%%

C = [0.5 0.1 0.2;0.25 0.6 0.15;0.25 0 0.5]
D = [  20000 ; 30000 ; 25000 ]
[l,k]=size(C)
I=eye(l)
A=(I-C)

[n,m]=size([A D]);

[L U P]= lu(A)

%Ly=b
% forward substitution to find y

[n,m]=size(L)
y=zeros(n,1)
y(1)=D(1)/L(1,1)
for i=2:1:n
  y(i)=(D(i)-L(i,1:i-1)*y(1:i-1,1))./L(i,i)
endfor
y

%Backward substitution
%Ux=y
[n,m]=size(U)
x=zeros(n,1)
x(n)=y(n)/U(n,n)
for i=n-1:-1:1
  x(i)=(y(i)-U(i,i+1:n)*x(i+1:n))./U( i , i )
endfor
disp("�")
disp("�")
x

fprintf('\n')
fprintf('\n')
fprintf('\n')
fprintf('\n')
fprintf('\n')
fprintf('\n')
fprintf('\n')
fprintf('\n')


%%% QUESTION D %%%%

C = [0.5 0.1 0.2;0.25 0.6 0.15;0.25 0 0.5];
D = [  158 ; 541 ; 981 ]
[l,k]=size(C);
I=eye(l);
A=(I-C)

[n,m]=size([A D]);

[L U P]= lu(A)

%Ly=b
% forward substitution to find y

[n,m]=size(L);
y=zeros(n,1);
y(1)=D(1)/L(1,1);
for i=2:1:n
  y(i)=(D(i)-L(i,1:i-1)*y(1:i-1,1))./L(i,i);
endfor
y

%Backward substitution
%Ux=y
[n,m]=size(U);
x=zeros(n,1);
x(n)=y(n)/U(n,n);
for i=n-1:-1:1
  x(i)=(y(i)-U(i,i+1:n)*x(i+1:n))./U( i , i );
endfor
disp("�")
disp("�")
x


