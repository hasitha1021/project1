
function  Doolittle_LU_decom_Method (A,D) 

disp("Doolittle�s LU decomposition Method")

% A = input-output coefficient matrix 
% D = External Demand matrix
fprintf('\n')

 Aug_Mat = [A D];
No_rows = size(Aug_Mat,1);
No_columns = size(Aug_Mat,2);

fprintf('The Augmented Matrix  = \n')
fprintf('\n')
disp(Aug_Mat)
err = 0;

A1=[A]

for i = 1 : No_rows-1
  for p = i : No_rows
    if (A(p,i)!=0) && (p==i)
      err = 0;
      break
    elseif (A(p,i)!=0) && (p!=i)
     A([p i],:)=A([i p],:) %Row Interchange
      err = 0 ;
      break
    else err = 1 ;
    endif
  endfor
  
  if err ==1
    break
  endif
  
  for  j=i+1 : No_rows
    fprintf('\n')
    m = A(j,i)/A(i,i)
    A(j,:) = A(j,:)-m*A(i,:) 
  endfor
  
endfor

U=A

L=A1*inverse(U)

Y = inverse(L)*D

New_Aug_Mat = [U Y]

if (New_Aug_Mat(No_rows,No_rows)==0) || (err==1)
     err=1;
     
     %Back Substitution for Find solutions
  else Xn= New_Aug_Mat(No_rows,No_columns)/ New_Aug_Mat(No_rows,No_rows);
    sol=zeros(No_rows,1);
    sol(No_rows)=Xn;
    
    for k=No_rows:-1:2
      sol(k-1)=( New_Aug_Mat(k-1,No_columns)- New_Aug_Mat(k-1,k-1:No_rows)*sol(k-1:No_rows))/ New_Aug_Mat(k-1,k-1);
    endfor
    
    for b=1:No_rows
      fprintf('* X%i = %.2f \n', b, sol(b))
    endfor
      fprintf('\n')
  endif
  
if err==1
    disp(["no unique solution"])
    fprintf('\n')
endif 
  
if New_Aug_Mat(No_rows,:)==0
    disp(["This Linear System of Equations has Infinitely Many Solutions"])
endif
  
if (New_Aug_Mat(No_rows,No_rows)==0) && (New_Aug_Mat(No_rows,No_columns)!=0)
    disp(["This Linear System of Equations has No Solution"])
endif
endfunction
