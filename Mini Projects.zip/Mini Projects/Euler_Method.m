function  [T,W]= Euler_Method (f,a,b,Yo,h)

disp("Euler�s method : s15652 ")
fprintf('\n')

  N = (b-a)/h;

  t = zeros(N+1,1);
  w = zeros(N+1,1);


n=0;
  w(1) = Yo;
  t(1) = a;


disp("n            ti            wi");
fprintf('%i \t %f\t %.5f \t  \n', n, t(1), w(1) )
  for i=1:N

    t(i+1,:) = t(i) + h;
    w(i+1,:) = w(i) + h*feval(f,t(i),w(i));


    n=n+1;

    fprintf('%i \t %f\t %.5f \t  \n', n, t(i+1), w(i+1) )

  endfor



 T = [t];
 W = [w];

endfunction
