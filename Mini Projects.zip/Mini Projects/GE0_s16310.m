clc
clear all
close all

% Mini Project 03 - s15652
% Inuka chandipa Sathsara - 2020s17894
% 2022 - 12 - 03


A1 = [pi -exp(1) 2^0.5 -3^0.5 ; pi^2 exp(1) -exp(2)  3/7 ; 5^0.5 -6^0.5 1 -2^0.5 ; pi^3 exp(2) -7^0.5 1/9]

fprintf('\n')
fprintf('\n')  

b = [11^0.5 ; 0 ; pi ; 2^0.5]

A=[A1 b];

Augmented_Matrix = A

[n,m]=size(A)

%Gaussian Elimination
for j=1:n-1
  for i=j+1:n
    if A(i,j)~=0
      A(i,:)=A(i,:)-(A(i,j)./A(j,j)).*A(j,:)
    endif
  endfor
endfor

A

%back substitution
x=zeros(m-1,1);
x(n)=A(n,m)/A(n,n);
for i=n-1:-1:1
  x(i)=(A(i,m)-A(i,i+1:n)*x(i+1:n))./A(i,i);
endfor
x

fprintf('\n')
fprintf('\n') 

X_1=GE1_s15652 (x)

%In here we can use simply --- --- str2int(mat2str(x,3))
