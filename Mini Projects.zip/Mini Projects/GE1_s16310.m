function  X_n=GE1_s15652 (x)
  
    %%% 3 - Significant Arithmetic Rounding Process %%%
    
rows = rows(x);
cols = columns(x);

fprintf('\n') 
X_n = zeros(rows,1);

for i = 1:rows;
  for j = 1:cols;
     b = sprintf("%.3g\n", x(i,j));   
     X_n(i,j) = str2num(b);
  endfor
endfor

endfunction
