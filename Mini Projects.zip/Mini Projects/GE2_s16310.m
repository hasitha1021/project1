clc
clear all
close all

A1 = [pi -exp(1) 2^0.5 -3^0.5 ; pi^2 exp(1) -exp(2)  3/7 ; 5^0.5 -6^0.5 1 -2^0.5 ; pi^3 exp(2) -7^0.5 1/9]
b = [11^0.5 ; 0 ; pi ; 2^0.5]

fprintf('\n')
fprintf('\n') 
fprintf('\n')
fprintf('\n') 

%%% 3 - Significant Arithmetic Rounding Process %%%

rows_A1 = rows(A1);
cols_A1 = columns(A1);
A1_3sig= zeros(rows_A1,cols_A1);

for i = 1:rows_A1;
  for j = 1:cols_A1;
     c = sprintf("%.3g\n", A1(i,j));   
     A1_3sig(i,j) = str2num(c);
  endfor
endfor
A1_3sig


rows_b = rows(b);
cols_b = columns(b);
b_3sig= zeros(rows_b,cols_b);

for i = 1:rows_b;
  for j = 1:cols_b;
     d = sprintf("%.3g\n", b(i,j));   
     b_3sig(i,j) = str2num(d);
  endfor
endfor
b_3sig


fprintf('\n')
fprintf('\n') 

A = [A1_3sig b_3sig]
 
[n,m]=size(A);

%Gaussian Elimination
for j=1:n-1
  for i=j+1:n
    if A(i,j)~=0
      A(i,:)=str2num(sprintf("%.3g\n",A(i,:)-(A(i,j)./A(j,j)).*A(j,:))) %%% 3 - Significant Arithmetic Rounding Process %%%
    endif
  endfor
endfor

A

fprintf('\n')
fprintf('\n') 


%back substitution
X_2=zeros(m-1,1);

X_2(n)=str2num(sprintf("%.3g\n",A(n,m)/A(n,n))); %%% 3 - Significant Arithmetic Rounding Process %%%

for i=n-1:-1:1
  X_2(i)=str2num(sprintf("%.3g\n",(A(i,m)-A(i,i+1:n)*X_2(i+1:n))./A(i,i))); %%% 3 - Significant Arithmetic Rounding Process %%%
endfor
X_2