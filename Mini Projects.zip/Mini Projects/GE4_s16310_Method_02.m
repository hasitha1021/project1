

%%% Code Given In the Tutorial Session %%%

A1 = [pi -exp(1) 2^0.5 -3^0.5 ; pi^2 exp(1) -exp(2)  3/7 ; 5^0.5 -6^0.5 1 -2^0.5 ; pi^3 exp(2) -7^0.5 1/9]
b = [11^0.5 ; 0 ; pi ; 2^0.5]

fprintf('\n')
fprintf('\n')
fprintf('\n')
fprintf('\n')

%%% 3 - Significant Arithmetic Rounding Process %%%

rows_A1 = rows(A1);
cols_A1 = columns(A1);
A1_3sig= zeros(rows_A1,cols_A1);

for i = 1:rows_A1;
  for j = 1:cols_A1;
     c = sprintf("%.3g\n", A1(i,j));
     A1_3sig(i,j) = str2num(c);
  endfor
endfor
A1_3sig


rows_b = rows(b);
cols_b = columns(b);
b_3sig= zeros(rows_b,cols_b);

for i = 1:rows_b;
  for j = 1:cols_b;
     d = sprintf("%.3g\n", b(i,j));
     b_3sig(i,j) = str2num(d);
  endfor
endfor
b_3sig


fprintf('\n')
fprintf('\n')

Aug=[A1_3sig b_3sig]
[n,m]=size(Aug);

for i=1:n
  s(i)=max(abs(Aug(i,1:n)));
endfor

s

for j=1:n-1

  % Scaled partial pivoting for column j
  % Find the element largest relative size and the correspoding row number p
  [Augmax,p]=max(abs(Aug(j:n,j)./s(j)));
  p=p+j-1;

  % If this element is very small matrix is singular
  eps=0.00002
  if Augmax < eps
    disp('Matrix is singular')
    break
  endif

  if p~=j
    C=Aug(j,:);
    Aug(j,:)=Aug(p,:);
    Aug(p,:)= C;

    C2=s(j);
    s(j)=s(p);
    s(p)=C2;

  endif

s

% Elimination process for column j
  for i=j+1:n
    if Aug(i,j)~=0
      Aug(i,:)=str2num(sprintf("%.3g\n",Aug(i,:)-Aug(j,:)./Aug(j,j).*Aug(i,j))) %%% 3 - Significant Arithmetic Rounding Process %%%
    endif
  endfor
endfor

Aug

%back substitution

X_4=zeros(m-1,1) ;
X_4(n)=str2num(sprintf("%.3g\n",Aug(n,m)/Aug(n,n))); %%% 3 - Significant Arithmetic Rounding Process %%%

for i=n-1:-1:1
  X_4(i)=str2num(sprintf("%.3g\n",(Aug(i,m)-Aug(i,i+1:n)*X_4(i+1:n))./Aug( i , i ))); %%% 3 - Significant Arithmetic Rounding Process %%%
endfor
X_4

%%% We can see using this method we can get more accurate answer %%%
