function x = Gauss_Seidel_Method (A, b,p,max)
  %A-co efficient matrix
  %b= answer matrix
  %p=inital guess
  %max=no. of iterations
  disp('gauss seidal method')
[n,m]=size(A);
x=zeros(m,1);
disp( ' n          x              y            z  ') % only for 3 variables
for i=1:max %no. of iterations
  for j=1:m %calculating x(i)
    if j==1
      x(1)=(b(1)-A(1,2:m)*p(2:m))./A(1,1);
    elseif j==m
      x(m)=(b(m)-A(m,1:m-1)*x(1:m-1))./A(m,m);
      else
  x(j)=(b(j)-A(j,1:j-1)*x(1:j-1)...
  -A(j,j+1:m)*p(j+1:m))./A(j,j);
  endif
endfor
i;
p=x;

fprintf( '%i \t %.4f \t %.4f \t %.4f \n', i , p(1), p(2), p(3))
endfor

fprintf('\n')
fprintf('\n')

fprintf(" solutions are " , x)
endfunction
