function x = Jacobi_Method (A, b,p,max)
  %A-co efficient matrix
  %b= answer matrix
  %p=inital guess
  %max=no. of iterations
     disp('Jacobi method')
     
[n,m]=size(A);
x=zeros(m,1);
disp( ' n          x              y            z  ') % only for 3 variables
for i=1:max %no. of iterations
  for j=1:m %calculating x(j)
  x(j)=(b(j)-A(j,[1:j-1,j+1:m])*p([1:j-1,j+1:m]))./A(j,j);
endfor


i;
p=x;

fprintf( '%i \t %.4f \t %.4f \t %.4f \n', i , p(1), p(2), p(3))
endfor

fprintf('\n')
fprintf('\n')

fprintf(" solutions are " , x)

endfunction
