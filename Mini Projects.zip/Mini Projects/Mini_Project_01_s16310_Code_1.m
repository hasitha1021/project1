clc
clear all
close all




% (-2,3) , (-1,5) , (0,1) , (1,4) , (2,10)

A1=[1 -2 4 -8 16;1 -1 1 -1 1;1 0 0 0 0;1 1 1 1 1;1 2 4 8 16]
b=[3;5;1;4;10]

A=[A1 b];

Augmented_Matrix = A

[n,m]=size(A)

%Gaussian Elimination
for j=1:n-1
  for i=j+1:n
    if A(i,j)~=0
      A(i,:)=A(i,:)-(A(i,j)./A(j,j)).*A(j,:)
    endif
  endfor
endfor

A

%back substitution
x=zeros(m-1,1);
x(n)=A(n,m)/A(n,n);
for i=n-1:-1:1
  x(i)=(A(i,m)-A(i,i+1:n)*x(i+1:n))./A(i,i);
endfor
x

fprintf('\n')
fprintf('\n')
fprintf('\n')
fprintf('\n')





%Method 2

%A * X = b
%X = inv(A1) * b




%Question 04
%poly5fit function

fprintf("poly5fit function")
fprintf('\n')
fprintf('\n')
fprintf('\n')

U=[1 -2 4 -8 16;0 1 -3 7 -15;0 0 2 -6 14;0 0 0 6 -12;0 0 0 0 24]
c=[3;2;-6;13;-17]
poly5fit(U,c)

fprintf('\n')
fprintf('\n')
fprintf('\n')
fprintf('\n')







%Question 05
%Plot the curve that you fitted for the data points.

x =linspace(-2.5,3,200);
y =1-1.25*x+4.2083*x.^2+0.75*x.^3-0.7083*x.^4;

figure
plot(x,y,'r')
grid on
title("y = 1 - 1.25x + 4.2083x^2 + 0.75x^3 - 0.7083x^4" ,"fontsize", 20)
xlabel('X',"fontsize", 20)
ylabel('Y',"fontsize", 20)


figure
plot(x,y,'r')
grid on
hold on
plot(-2,3,'k+')
plot(-1,5,'ko')
plot(0,1,'kx')
plot(1,4,'kd')
plot(2,10,'ks')
legend('Fitted graph','(-2,3) ','(-1,5)','(0,1)','(1,4)','(2,10)',"fontsize", 20)
title("y = 1 - 1.25x + 4.2083x^2 + 0.75x^3 - 0.7083x^4" ,"fontsize", 20)
xlabel('X',"fontsize", 20)
ylabel('Y',"fontsize", 20)
