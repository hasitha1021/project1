clc
clear all
close all


%For all calculation i enter 5 , N = input("Enter a Number(n) : ") = 5

#QUESTION (a)

H=[ 1 1/2 1/3 1/4 1/5; 1/2 1/3 1/4 1/5 1/6; 1/3 1/4 1/5 1/6 1/7;
1/4 1/5 1/6 1/7 1/8; 1/5 1/6 1/7 1/8 1/9]

Transpose_of_H = transpose(H)

fprintf('\n')
fprintf('\n')



#QUESTION (b)

for n = 3:30
  D = det(hilb(n));
  fprintf('Det_of_Hilb_%i = %x \n', n, D) 
  fprintf('\n')
endfor

#QUESTION (c) Answer is in the pdf

fprintf('\n')
fprintf('\n')


#QUESTION (d)

% H = hilb(N)
% Hx = b
% x = inv(H) * b
% x = [1;1;1;1;....] upto N (N number of ones)

% b = Hx
Ho = hilb(5)
b=sum(Ho,2)

fprintf('\n')
fprintf('\n')



#QUESTION (e)


% H = hilb(N)
% Hx = b
% x = inv(H) * b
% x = [1;1;1;1;....] upto N (N number of ones)

% b = Hx

N = input("Enter a Number(n) : "); %n=5
H = hilb(N)
x = ones(N,1) 
b = hilb(N) * x

x1 = inv(H) * b  % Use separate octave file . Then we can see ill-conditioned system.


fprintf('\n')
fprintf('\n')
fprintf('\n')
fprintf('\n')

#QUESTION (f)


#bnew = b + delta(b)
% b = Hx
% x = [1;1;1;1;....] upto N (N number of ones)
%?b =[0;0;0;0;�.;0;0.0001]

# Hx = b + ?b 
# x_new = inv(H)*b +inv(H)*delta_b 
# x_new = inv(H)*H* x +inv(H)*delta_b  
# x_new = I* x +inv(H)*delta_b 
# x_new = x +inv(H)*delta_b  

%%% Notice that x_new = x_tilda %%%

N = input("Enter a Number(n) : "); %n=5
H1 = hilb(N)
x = ones(N,1)
delta_b = zeros(N-1,1)
delta_b(N,:)=[10^-4]

x_new = x + inv(H1) *delta_b
% Notice that x_new = x_tilda

fprintf('\n')
fprintf('\n')

#QUESTION (g)
%in here we take n = 5 for all variables [ x,x_new,b,delta_b ] i.e. Usser Input is 5

%Method 1 

K2_min = (norm(x-x_new,2)*norm(b,2))/(norm(x,2)*norm(delta_b,2))

fprintf('\n')

%Method 2
H = hilb(5)
Condition_Number = norm(H,2) * norm(inv(H),2)
 


fprintf('\n')
fprintf('\n')

#QUESTION (h)
%in here we take n = 5

N = input("Enter a Number(n) : "); %n=5
H=hilb(N)
Condition_no_H = cond(H)



