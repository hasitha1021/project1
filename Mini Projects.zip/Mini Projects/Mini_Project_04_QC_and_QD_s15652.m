clc
clear all
close all

C = [0.5 0.1 0.2 ; 0.25 0.6 0.15 ; 0.25 0 0.5]
D1 = [ 20000 ; 30000 ; 25000]
A1 = eye(size(C,1)) - C

Doolittle_LU_decom_Method(A1,D1)

fprintf('\n')
fprintf('\n')
fprintf('\n')
fprintf('\n')


C = [0.5 0.1 0.2 ; 0.25 0.6 0.15 ; 0.25 0 0.5]
D2 = [ 158 ; 541 ; 981]
A2 = eye(size(C,1)) - C

Doolittle_LU_decom_Method(A2,D2)