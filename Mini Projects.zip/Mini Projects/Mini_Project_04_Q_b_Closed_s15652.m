clc
clear all
close all

% Leontief Input-Output Models
% QUESTION (b)
% Closed System --> X = AX
 
% X = [ E ; W ; C ] Production Vector.
% Lambda*X = AX
% AX - Lambda*X = 0
% [ A - Lambda*I ] X = 0


A = [0.5 0.1 0.2 ; 0.25 0.6 0.15 ; 0.25 0 0.5]
I = eye(3)
b = [0 ; 0 ; 0]
lambda = eig(A)

fprintf('\n')
fprintf('\n')
fprintf('\n')
fprintf('\n')

lambda(1)
I_A1 = A - lambda(1).* I
A_Update1 = [I_A1 b]
Red_Row_Ec_Form1 = rref(A_Update1) %Reduce Row Echelon Form Function ---> rref
A1 = Red_Row_Ec_Form1


[n,m] = size(A1);


X1=zeros(m-1,1);
if and(A1(n,m)==0,A1(n,n)==0)
  X1(n) = 1;
else
  X1(n)=A1(n,m)/A1(n,n);
endif
for i=n-1:-1:1
  X1(i)=(A1(i,m)-A1(i,i+1:n)*X1(i+1:n))./A1(i,i);
endfor
X1

fprintf('\n')
fprintf('\n')
fprintf('\n')
fprintf('\n')

lambda(2)
I_A2 = A - lambda(2)* I
A_Update2 = [I_A2 b]
Red_Row_Ec_Form2 = rref(A_Update2)
A2 = Red_Row_Ec_Form2

[n,m] = size(A2);
X2=zeros(m-1,1);
if and(A2(n,m)==0,A2(n,n)==0)
  X2(n) = 1;
else
  X2(n)=A2(n,m)/A2(n,n);
endif
for i=n-1:-1:1
  X2(i)=(A2(i,m)-A2(i,i+1:n)*X2(i+1:n))./A2(i,i);
endfor
X2


fprintf('\n')
fprintf('\n')
fprintf('\n')
fprintf('\n')

lambda(3)
I_A3 = A - lambda(3)* I
A_Update3 = [I_A3 b]
Red_Row_Ec_Form3 = rref(A_Update3)
A3 = Red_Row_Ec_Form3

[n,m] = size(A3);
X3=zeros(m-1,1);
if and(A3(n,m)==0,A3(n,n)==0)
  X3(n) = 1;
else
  X3(n)=A3(n,m)/A3(n,n);
endif
for i=n-1:-1:1
  X3(i)=(A3(i,m)-A3(i,i+1:n)*X3(i+1:n))./A3(i,i);
endfor
X3
