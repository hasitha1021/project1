s="F+F+F+F";
ang=pi/2;
iniang=pi/2;
ang1=ang;
d=1;
initialx=0;
initialy=0;

M=[initialx;initialy;iniang]
for i=1:length(s)
  if s(i)=="+"
    ang1=(M(:,end)(3)+ang)
  elseif s(i)=="-"
    ang1=M(:,end)(3)-ang
      elseif s(i)=="F"
    x=M(:,end)(1)+d*cos(ang1);
    y=M(:,end)(2)+d*sin(ang1);
    M=[M,[x;y;ang1]]
  endif
endfor
plot(M(1,:), M(2,:))


k="F+F+F+F"

%for i=1:n
 % w(i)=input("Enter the letters in the word: ","s")
%endfor
%printf("%s\n",w)

a=ones(1,length(k)).*(pi/2)
d=1;
x=zeros(1,length(k))
y=zeros(1,length(k))
l=1;
for i=1:length(k);

  if k(i)=="F"
    x(i+1)=x(i)+cos(a(i))*d;
    y(i+1)=y(i)+sin(a(i))*d;
    a(i+1)=a(i);
  endif
  if k(i)=="+"
    a(i+1)=a(i)+(pi/2);
    x(i+1)=x(i);
    y(i+1)=y(i);
  endif
  if k(i)=="-"
    a(i+1)=a(i)-(pi/2);
    x(i+1)=x(i);
    y(i+1)=y(i);
  endif


endfor
disp([x',y',a'])
figure
plot(x,y,"color","red")

