% Set the initial state of the turtle
pos = [0; 0];  % starting position
angle = 0;     % starting angle (in degrees)
step_size = 1;  % step size for each forward movement
angle_increment = pi/4;  % angle increment for each turn

% Create an empty stack to keep track of the turtle's state
stack = [];

% Define the drawing instructions
instructions = 'F[+F][-F]';

% Loop through each instruction in the string
for i = 1:length(instructions)
    instruction = instructions(i);

    % Move forward
    if instruction == 'F'
        new_pos = pos + step_size * [cos(angle); sin(angle)];
        line([pos(1), new_pos(1)], [pos(2), new_pos(2)]);
        pos = new_pos;

    % Turn left
    elseif instruction == '+'
        angle = angle + angle_increment;

    % Turn right
    elseif instruction == '-'
        angle = angle - angle_increment;

    % Save the turtle's state
    elseif instruction == '['
        stack(end+1,:) = [pos' angle];

    % Restore the turtle's state
    elseif instruction == ']'
        state = stack(end,:);
        pos = state(1:2)';
        angle = state(3);
        stack(end,:) = [];
    end
end
