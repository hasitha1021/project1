clear all
clc
%w="F[+F][-F]"
w="[F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]";
n=length(w)
a=ones(1,n)*0;
x=zeros(1,n);
y=zeros(1,n);
A=0;
X=0;
Y=0;
;

d=1;
w="[F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]";
printf("%s \n",w);

for i=1:n
  if w(i)=='F'
    x(i+1)=x(i)+cosd(a(i))*d;
    y(i+1)=y(i)+sind(a(i))*d;
    a(i+1)=a(i);
  endif

  if w(i)=='+'
    a(i+1)=a(i)+45;
    x(i+1)=x(i);
    y(i+1)=y(i);

  endif

  if w(i)=='-'
    a(i+1)=a(i)-45;
    x(i+1)=x(i);
    y(i+1)=y(i);

  endif

  if w(i)=='['
    a(i+1)=a(i);
    x(i+1)=x(i);
    y(i+1)=y(i);
    A=a(i);
    X=x(i);
    Y=y(i);
  endif

  if w(i)==']'
    a(i+1)=A;
    x(i+1)=X;
    y(i+1)=Y;
  endif

endfor

x;
y;
disp("          X          Y        Alpha")
fprintf('\n')
disp("          0          0          0")
disp([   x'  ,   y',   a'])
plot(x,y,'color','red')

