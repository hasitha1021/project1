w="[F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]";
n=length(w)
a=zeros(1,n);
x=zeros(1,n);
y=zeros(1,n);
A=0;
X=0;
Y=0;

d=1;

printf("%s \n",w)
disp('symbol         x           y               alpha' )
fprintf('\t %.7f\t %.7f \t %i\n',x(1), y(1), a(1))

for i=1:n
  if w(i)=='F'
    x(i+1)=x(i)+cos(a(i))*d;
    y(i+1)=y(i)+sin(a(i))*d;
    a(i+1)=a(i);
  endif

  if w(i)=='+'
    a(i+1)=a(i)+pi/4;
    x(i+1)=x(i);
    y(i+1)=y(i);

  endif

  if w(i)=='-'
    a(i+1)=a(i)-pi/4;
    x(i+1)=x(i);
    y(i+1)=y(i);

  endif

  if w(i)=='['
    a(i+1)=a(i);
    x(i+1)=x(i);
    y(i+1)=y(i);
    A=a(i);
    X=x(i);
    Y=y(i);
  endif

  if w(i)==']'
    a(i+1)=A;
    x(i+1)=X;
    y(i+1)=Y;
  endif

  fprintf('%s \t %.6f\t %.6f \t %i\n', (w(i)), x(i+1), y(i+1), a(i+1)*(180/pi))
endfor

plot(x,y,'color','black')
