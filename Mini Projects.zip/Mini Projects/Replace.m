clc
clear all
close all

w0="FX";
r0="FF";
r1="F+[[X]-X]-F[-FX]+X";

n1=2;
for i=1:n1;
  w1=[""];
  t=length(w0);

  for i=1:t;
    if w0(i)=="F"
      w1=[w1 r0];
    endif

    if w0(i)=="X"
      w1=[w1 r1];
    endif

    if w0(i)=="+"
      w1=[w1 "+"];
    endif

    if w0(i)=="-"
      w1=[w1 "-"];
    endif

    if w0(i)=="["
      w1=[w1 "["];
    endif

    if w0(i)=="]"
      w1=[w1 "]"];
    endif
  endfor
w0=w1;
endfor
w=w1

theta=25;
n=length(w);
an=ones(1,n)*pi/180;
x=zeros(1,n);
y=zeros(1,n);
M=zeros(1,3);
x(1)=0;
y(1)=0;
an(1)=pi/3;
for i=1:n
  if w(i)=="F"
    x(i+1)=x(i)+1*cos(an(i));
    y(i+1)=y(i)+1*sin(an(i));
    an(i+1)=an(i);
  endif

  if w(i)=="+"
    an(i+1)=an(i)+deg2rad(theta);
    x(i+1)=x(i);
    y(i+1)=y(i);

  endif

  if w(i)=="-"
    an(i+1)=an(i)-deg2rad(theta);
    x(i+1)=x(i);
    y(i+1)=y(i);
  endif

  if w(i)=="["
    M=[M;x(i),y(i),an(i)];
    x(i+1)=x(i);
    y(i+1)=y(i);
    an(i+1)=an(i);
  endif

 if w(i)=="X"
    x(i+1)=x(i);
    y(i+1)=y(i);
    an(i+1)=an(i);
  endif

  if w(i)=="]"
    x(i+1)=M(end,1);
    y(i+1)=M(end,2);
    an(i+1)=M(end,3);
    M(end,:)=[];
  endif
endfor

t=an*180/(pi);

#disp(["         x           y     alpha"]);
#disp([x' y' t']);
plot(x,y,'r-')
title("turtle graph")
xlabel("x")
ylabel("y")
