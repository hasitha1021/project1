function [T,W,err]= Rung_Kutta_Or4_err (f,g,a,b,Yo,h)

disp("Runge-Kutta Order 4 :- s15652")
fprintf('\n')

  N = (b-a)/h;
  h
  t = zeros(N+1,1);
  w = zeros(N+1,1);
  y = zeros(N+1,1);

n=0;
  w(1) = Yo;
  t(1) = a;
  y(1) = Yo;
  err(1) =abs(y(1)-w(1));

disp(" n             ti             wi                        yi               abs. error");
fprintf('%i \t %f\t %.7f \t %.7f \t %.7f\n', n, t(1), w(1), y(1) , err(1))

  for i=1:N

    t(i+1,:) = t(i) + h;

    k1 = h*feval(f,t(i),w(i));
    k2 = h*feval(f,t(i)+(h/2),w(i)+(k1/2));
    k3 = h*feval(f,t(i)+(h/2),w(i)+(k2/2));
    k4 = h*feval(f,t(i+1),w(i)+k3);


    w(i+1,:) = w(i) + (1/6)*( k1 + 2*k2 + 2*k3 + k4);

    y(i+1,:) = feval(g,t(i+1));
    %this is the exact solution of the problem
    % If we want we can get this as input
    err(i+1,:)= abs(y(i+1) -w(i+1));

    n=n+1;

    fprintf('%i \t %f\t %.7f \t %.7f \t %.7f\n', n, t(i+1), w(i+1), y(i+1) , err(i+1))

  endfor



 T = [t];
 W = [w];

endfunction
