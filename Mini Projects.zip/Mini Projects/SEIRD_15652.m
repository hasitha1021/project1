function d = SEIRD_15652 (t,x,u)

#x is the (5,1)  column vector containing numbers of :-
#susceptible(x(1)),
#Exposed(x(2)),
#Infected(x(3)),
#Removed(x(4))
#Deaths(x(5)).
#These are functions of the independent variable

#t (time).

#u control parameter



No      = 10000000;
alpha   = 0.006;
beta    = 0.75;
gamma   = 1/8;
epsilon = 1/3;
mu      = 1/(83*365);  # mu^(-1) = 83
A       = mu * No;

  d = zeros(5,1);

  d(1) = A - mu*x(1)-(1-u)*beta*x(1)*(x(3)/No);
  d(2) = (1-u)*beta*x(1)*(x(3)/No) - (mu+epsilon)*x(2);
  d(3) = epsilon*x(2) - (gamma+mu+alpha)*x(3);
  d(4) = gamma*x(3) - mu*x(4);
  d(5) = alpha * x(3);
endfunction
