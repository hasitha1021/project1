clear all
close all
clc

k=" [F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]"
fprintf('\n')
fprintf('\n')

%for i=1:n
 % w(i)=input("Enter the letters in the word: ","s")
%endfor
%k1=" [F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]-[F+F]";
%h = printf("%s\n",k1);

a=ones(1,length(k)).*(0);
d=1;
x=zeros(1,length(k));
y=zeros(1,length(k));
alpha =45;

j = 1;
M =zeros(1,3);

disp("Symbol        X             Y          Alpha")
fprintf("\n")

for i=1:length(k);

  if k(i)=="F"
    x(i+1)=x(i)+cosd(a(i))*d;
    y(i+1)=y(i)+sind(a(i))*d;
    a(i+1)=a(i);
  endif
  if k(i)=="+"
    a(i+1)=a(i)+(alpha);
    x(i+1)=x(i);
    y(i+1)=y(i);
  endif
  if k(i)=="-"
    a(i+1)=a(i)-(alpha);
    x(i+1)=x(i);
    y(i+1)=y(i);
  endif

  if k(i) =="["
    j=j+1;
    M =[M;x(i),y(i),a(i)];
    a(i+1)=a(i);
    x(i+1)=x(i);
    y(i+1)=y(i);
  endif
  if k(i) =="x"
    a(i+1)=a(i);
    x(i+1)=x(i);
    y(i+1)=y(i);
  endif
  if k(i) =="]"
    a(i+1)=M(end,3);
    x(i+1)=M(end,1);
    y(i+1)=M(end,2);
  endif

  fprintf('%s \t %.6f\t %.7f \t %i\n', (k(i)), x(i+1), y(i+1), a(i+1))
endfor


plot(x,y,"color","red")
title('The Turtle graphics interpretation -L Systems ',"fontsize", 20)
xlabel('X',"fontsize", 20)
ylabel('Y',"fontsize", 20)
grid on
