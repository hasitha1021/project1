clear all
close all
clc

No = 10000000;
Eo = 20000;
Io = 1;
Ro = 0;
So = No - Eo - Io;
D0 = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%PLOTS PART (a)

A = [0.8,0.6,0.5,0.4,0.3];

for i = 1:length(A)

[time,x,u] = ode45('SEIRD_15652',[0:400],[So,Eo,Io,Ro,D0],A(i));
plot(time,x(:,3),"linewidth",1)

hold on
grid on
endfor


title('Variations of Infected Population (I) for control parameter (u)',"fontsize", 20)
xlabel('Time',"fontsize", 20)
ylabel('Infected Population  ',"fontsize", 20)
legend('u=0.8','u=0.6','u=0.5','u=0.4','u=0.3',"fontsize", 20)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%PLOTS PART (c)

A = [0.8,0.6,0.5,0.4,0.3];

figure

for n = 1:length(A)

[time,x,u] = ode45('SEIRD_15652',[0:1000],[So,Eo,Io,Ro,D0],A(n));
plot(time,x(:,5),"linewidth",1)

hold on
grid on
endfor


title('Variations of Death Population (D) for control parameter (u)',"fontsize", 20)
xlabel('Time',"fontsize", 20)
ylabel('Death Population  ',"fontsize", 20)
legend('u=0.8','u=0.6','u=0.5','u=0.4','u=0.3',"fontsize", 20)
