%Only the code for the rewrite

clear all
clc
n = input("Number of rewrites: ");
count=0 ;% To count the no of rewrites and print the answer. Not necessary.

W0=["FX"]
%axioms
repF="FF"
repx="[+FX][-FX]"
repb1="[";
repb2="]";
repp="+";
repn="-";
%length of the strings of axioms
nrep=length(repF);
Mrep=length(repx);
nrepb1=length(repb1);
nrepb2=length(repb2);
nrepp=length(repp);
nrepn=length(repn);
% Definig the final outputs
finalstr=W0;
% To store the original string of the particular rewrite
finalstrOri=W0;

for j=1:n
k=length(finalstr) % length of the string
noo=1; % To count the place of the string that should be replaced.
for i=1:k

if finalstrOri(i)=="F"
 finalstr(noo:noo+nrep-1)="FF"; % noo:noo+nrep-1 is to show the number of places the string should be replaced.
  noo=noo+nrep; % to count the place of the string.

 elseif finalstrOri(i)=="X"

 finalstr(noo:noo+Mrep-1)=repx;
 noo=noo+Mrep;

 elseif finalstrOri(i)=="["
 finalstr(noo)="[";
 noo=noo+nrepb1;

 elseif finalstrOri(i)=="]"
 finalstr(noo)="]";
 noo=noo+nrepb2;

 elseif  finalstrOri(i)=="+"
 finalstr(noo)="+";
 noo=noo+nrepp;

 elseif finalstrOri(i)=="-"
 finalstr(noo)="-";
 noo=noo+nrepn;

endif
endfor
finalstrOri=finalstr;
count=count+1;
fprintf("Rewrite Number %i is %s \n " , count, finalstr)
endfor
