clc
#b

for n = 3:30
  D = det(hilb(n))
  fprintf('\n')
endfor

#c when n is increasing Det(H)  is decreasing to zero.

%%% For all below calculations H = hilb(5)


#d
H = hilb(5)
x=[1;1;1;1;1]
b=H*x

#e
x = inv(H) *b


#f
H = hilb(5)
x = ones(5,1)
del_b = zeros(5-1,1)
del_b(5,:)=[10^-4]

x_new = x + inv(H) *del_b

#g
K2_min = (norm(x-x_new,2)*norm(b,2))/(norm(x,2)*norm(del_b,2))

#h
Condition_no_H = cond(H)