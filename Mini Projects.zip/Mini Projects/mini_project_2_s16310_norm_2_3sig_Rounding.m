clc
clear all
close all

%%% QUESTION (f)

X_1 = [0.788; -3.13; 0.168; 4.56]
X_2 = [0.743; -2.95; 0.126; 4.17]
X_3 = [0.809; -3.21; 0.174; 4.74]
X_4_Method_1 = [0.739; -2.96; 0.128; 4.18]
X_4_Method_2 = [0.809; -3.21; 0.174; 4.74]

fprintf('\n')
fprintf('\n') 
fprintf('\n')
fprintf('\n')


Norm1 = norm(X_1-X_2,2)
Norm2 = norm(X_1-X_3,2)
Norm3_Method_1 = norm(X_1-X_4_Method_1,2)
Norm3_Method_2 = norm(X_1-X_4_Method_2,2)

fprintf('\n')
fprintf('\n') 
fprintf('\n')
fprintf('\n')


%%%% Addtional %%%

A1 = [pi -exp(1) 2^0.5 -3^0.5 ; pi^2 exp(1) -exp(2)  3/7 ; 5^0.5 -6^0.5 1 -2^0.5 ; pi^3 exp(2) -7^0.5 1/9]
b = [11^0.5 ; 0 ; pi ; 2^0.5]

A = [A1 b]

A_3sig = str2num(mat2str(A,3)) 

% I use for loop to rounding.
% But this is the another way.
% This is more simple than using for loop.

% For pivot step we use below mentioned code.

% row = str2num(sprintf("%.3g\n",calculations))
