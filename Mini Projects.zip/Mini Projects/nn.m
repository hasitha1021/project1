close all
clear all

  disp(" answer for second code")

W0="FX" ;
r0="FF";
r1="[+FX][-FX]";  %"F+[[X]-X]-F[-FX]+X";


disp(" x               y         angle")

for t=1:6
  W1=[""];
  p=length(W0);
  for i=1:p

    if  W0(i)=="F"
      W1=[W1 r0];
    endif

    if  W0(i)=="X"
      W1=[W1 r1];
    endif

    if  W0(i)=="+"
      W1=[W1 "+"];
    endif

    if  W0(i)=="-"
      W1=[W1 "-"];
    endif

    if  W0(i)=="["
      W1=[W1 "["];
    endif

    if  W0(i)=="]"
      W1=[W1 "]"];
    endif

   endfor
   W0=W1;


endfor


n=length(W0); %n=input("number of charectors")
ang=pi/3;
a=ones(1,n)*ang; % the initial angle
x=zeros(1,n);
y=zeros(1,n);
d=1;
delta=rad2deg(25);
M=zeros(1,3) % store the values

for i=1:n
  if W0(i)=="F"
    x(i+1)=x(i)+d*cos(a(i));
    y(i+1)=y(i)+d*sin(a(i));
    a(i+1)=a(i);
  endif

  if W0(i)=="+"
    x(i+1)=x(i);
    y(i+1)=y(i);
    a(i+1)=a(i)+delta;
  endif


   if W0(i)=="-"
    x(i+1)=x(i);
    y(i+1)=y(i);
    a(i+1)=a(i)-delta;
  endif

  if W0(i)=="["
    x(i+1)=x(i);
    y(i+1)=y(i);
    a(i+1)=a(i);
    M=[M;  x(i+1) y(i+1) a(i+1)];
  endif

  if W0(i)=="X"
    x(i+1)=x(i);
    y(i+1)=y(i);
    a(i+1)=a(i);
  endif


   if W0(i)=="]"
    x(i+1)=M(end,1);
    y(i+1)=M(end,2);
    a(i+1)=M(end,3);
     M(end,:)=[]; % Deletion of the used point;
  endif

  fprintf('    %i\t   %c \t %.6f  \t %.6f\t  %.3f\n',      i         ,W0(i)       ,x(i+1)      , y(i+1)     ,rad2deg(a(i+1)));

endfor



figure
  plot (x,y,"r")
  xlabel("x")
  ylabel("y")
  title(" path changes W0ith�code�legnth")
