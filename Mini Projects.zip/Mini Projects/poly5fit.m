function X = poly5fit (U, c)
  
  X = U\c;

endfunction
