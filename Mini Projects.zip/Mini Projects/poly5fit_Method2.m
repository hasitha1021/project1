function X = poly5fit_Method2 (U, c)
      Aug = [U c];
      [n,m]=size(Aug);
      
x=zeros(m-1,1);
x(n)=Aug(n,m)/Aug(n,n);
for i=n-1:-1:1
  x(i)=(Aug(i,m)-Aug(i,i+1:n)*x(i+1:n))./Aug(i,i);
endfor
x
endfunction
