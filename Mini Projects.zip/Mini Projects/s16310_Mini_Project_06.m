clear all
close all
clc

a = 1790
b = 1850         # 1850 , 1900 , 1990 , 2020
r = 0.0318
p0= 3900000
k = 200000000
h = 0.1           # 0.1, 0.01 , 1
t = b-a

F1 = @(t,p) r*p *(1-(p/k))

[T,W]= Euler_Method (F1,a,b,p0,h);


figure
plot(T, W, 'g','Linewidth',1)
title('The predicted population in USA for the year 2020',"fontsize", 20)
xlabel('Year',"fontsize", 20)
ylabel('Population  ',"fontsize", 20)
grid on

trange = [a:1:b];
[T1,W1] = ode45(F1,trange,p0)

hold on
plot(T1, W1, 'k','Linewidth',1)
