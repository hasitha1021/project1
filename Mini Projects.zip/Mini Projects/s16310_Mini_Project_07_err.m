clear all
close all
clc

a = 1790
b = 1850    # 1850 , 1900 , 1990 , 2020 , 2050
r = 0.0318
p0= 3900000
k = 200000000
h = 0.1             # 0.1, 0.01 , 1
t = b-a

F1 = @(t,p) r*p *(1-(p/k))
G1 = @(t) k*p0 /p0+(k-p0)*exp(-r*t)

[T1,W1,err1]= Rung_Kutta_Or4_err (F1,G1,a,b,p0,h);



plot(T1, W1, 'g','Linewidth',2)
title('The predicted population in USA for the year 2020',"fontsize", 20)
xlabel('Year',"fontsize", 20)
ylabel('Population  ',"fontsize", 20)
grid on
