clear all
close all
clc

No = 10000000;
Eo = 20000;
Io = 1;
Ro = 0;
So = No - Eo - Io;
D0 = 0;


[time,x,u] = ode45('SEIRD_15652',[0:100],[So,Eo,Io,Ro,D0],0.8);

# PLOTS Part (a)

figure

[time,x,u] = ode45('SEIRD_15652',[0:100],[So,Eo,Io,Ro,D0],0.8)
plot(time,x(:,3),"linewidth",1)

hold on
grid on

[time,x,u] = ode45('SEIRD_15652',[0:100],[So,Eo,Io,Ro,D0],0.6);
plot(time,x(:,3),"linewidth",1)

[time,x,u] = ode45('SEIRD_15652',[0:100],[So,Eo,Io,Ro,D0],0.5);
plot(time,x(:,3),"linewidth",1)

[time,x,u] = ode45('SEIRD_15652',[0:100],[So,Eo,Io,Ro,D0],0.4);
plot(time,x(:,3),"linewidth",1)

[time,x,u] = ode45('SEIRD_15652',[0:100],[So,Eo,Io,Ro,D0],0.3);
plot(time,x(:,3),"linewidth",1)

title('Variations of Infected Population (I) for control parameter (u)',"fontsize", 20)
xlabel('Time',"fontsize", 20)
ylabel('Infected Population  ',"fontsize", 20)
legend('u=0.8','u=0.6','u=0.5','u=0.4','u=0.3',"fontsize", 20)

# The reproduction number values for u=0.8,0.6,0.5,0.4, and 0.3.
# Part (b)

No      = 10000000;
alpha   = 0.006;
beta    = 0.75;
gamma   = 1/8;
epsilon = 1/3;
mu      = 1/(83*365);  # mu^(-1) = 83
A       = mu * No;

u = [0.8,0.6,0.5,0.4,0.3]

for i = 1:length(u)
  Ro = [(1-u(i))*(beta * epsilon)]/[(epsilon+mu)*(gamma+alpha+mu)];
  fprintf('R0_u%i = %.5f \n', i, Ro);
endfor


# PLOTS Part (c)

figure

[time,x,u] = ode45('SEIRD_15652',[0:1000],[So,Eo,Io,Ro,D0],0.8);
plot(time,x(:,5),"linewidth",1)

hold on
grid on

[time,x,u] = ode45('SEIRD_15652',[0:1000],[So,Eo,Io,Ro,D0],0.6);
plot(time,x(:,5),"linewidth",1)

[time,x,u] = ode45('SEIRD_15652',[0:1000],[So,Eo,Io,Ro,D0],0.5);
plot(time,x(:,5),"linewidth",1)

[time,x,u] = ode45('SEIRD_15652',[0:1000],[So,Eo,Io,Ro,D0],0.4);
plot(time,x(:,5),"linewidth",1)

[time,x,u] = ode45('SEIRD_15652',[0:1000],[So,Eo,Io,Ro,D0],0.3);
plot(time,x(:,5),"linewidth",1)

title('Variations of Death Population (D) for control parameter (u)',"fontsize", 20)
xlabel('Time',"fontsize", 20)
ylabel('Death Population  ',"fontsize", 20)
legend('u=0.8','u=0.6','u=0.5','u=0.4','u=0.3',"fontsize", 20)
