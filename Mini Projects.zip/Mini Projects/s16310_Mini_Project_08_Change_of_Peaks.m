clear all
close all
clc

No = 10000000;
Eo = 20000;
Io = 1;
Ro = 0;
So = No - Eo - Io;
D0 = 0;


# PLOT Part(e)

A = [0.3,0.4,0.5,0.6,0.8]
fprintf('\n')

for i = 1:length(A)

[time,x,u] = ode45('SEIRD_15652',[0:1000],[So,Eo,Io,Ro,D0],A(i));

U = A(i)
peak_of_death_population = max(x(:,5))
fprintf('\n')
fprintf('\n')

plot(A(i),max(x(:,5)),"*",'MarkerSize',20)
grid on
hold on

endfor

title('The change in the peak of death population(D_m_a_x)  with respect to the control parameter (u)',"fontsize", 20)
xlabel('control parameter(u)',"fontsize", 20)
ylabel('peak of death population(D_m_a_x)  ',"fontsize", 20)
legend('u=0.3','u=0.4','u=0.5','u=0.6','u=0.8',"fontsize", 20)
