clc
clear all
close all

A = [1 0 1 ; -1 1 0 ; 1 2 -3 ]
b = [ 2 ; 0 ; 0 ]

# Question B
# (1) Results when the maximum number of iterations is 200 , Gauss-Seidel  method
n = 200
fprintf('\n')

Po1 = [0 ; 0 ; 0]
Gauss_Seidel_Method  (A, b,Po1,n)

fprintf('\n')
fprintf('\n')
fprintf('\n')

Po2 = [1 ; 0 ; 1]
Gauss_Seidel_Method  (A, b,Po2,n)

fprintf('\n')
fprintf('\n')
fprintf('\n')

Po3 = [2 ; -1 ; 0]
Gauss_Seidel_Method  (A, b,Po3,n)

fprintf('\n')
fprintf('\n')
fprintf('\n')

Po4 = [1 ; 1 ; 1]
Gauss_Seidel_Method(A, b,Po4,n)


fprintf('\n')
fprintf('\n')
fprintf('\n')

Po5 = [1 ; 2 ; 0]
Gauss_Seidel_Method(A, b,Po5,n)


fprintf('\n')
fprintf('\n')
fprintf('\n')