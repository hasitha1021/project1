clc
clear all
close all

A = [1 0 1 ; -1 1 0 ; 1 2 -3 ]
b = [ 2 ; 0 ; 0 ]

Po1 = [0 ; 0 ; 0];
Po2 = [1 ; 0 ; 1];
Po3 = [2 ; -1 ; 0];
Po4 = [1 ; 1 ; 1];
Po5 = [1 ; 2 ; 0];

n1 = 10;
n2 = 50;
n3 = 200;

#We need to update only n1,n2 and n3 and Po1,Po2,Po3,Po4,and Po5 in each situation.......

Jacobi_Method (A, b,Po1,n1)

fprintf('\n')
fprintf('\n')
fprintf('\n')


Gauss_Seidel_Method  (A, b,Po1,n1)