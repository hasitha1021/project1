% rewrite and drawing the graph

clear all
clc
n = input("Number of rewrites: "); %Give input as positive integer
fprintf("\n")
count=0 ;% To count the no of rewrites and print the answer. Not necessary.

W0=["X"]
%axioms
repF="FF" % change of F
repx="F++X--F-X++X-UFFU" %  Change of X
repb1="["; % change of [
repb2="]"; % change of ]
repp="+";  % change of +
repn="-";  % change of -
repm="U";  % change of U

%length of the strings of axioms
nrep=length(repF);
Mrep=length(repx);
nrepb1=length(repb1);
nrepb2=length(repb2);
nrepp=length(repp);
nrepn=length(repn);
nrepm=length(repm);

% Definig the final outputs
finalstr=W0;
% To store the original string of the particular rewrite
finalstrOri=W0;

for j=1:n
k=length(finalstr); % length of the string
noo=1; % To count the place of the string that should be replaced.
for i=1:k

if finalstrOri(i)=="F"
 finalstr(noo:noo+nrep-1)="FF"; % noo:noo+nrep-1 is to show the number of places the string should be replaced.
  noo=noo+nrep; % to count the place of the string.

 elseif finalstrOri(i)=="X"

 finalstr(noo:noo+Mrep-1)="F++X--F-X++X-UFFU";
 noo=noo+Mrep;
 elseif finalstrOri(i)=="["
 finalstr(noo)="[";
 noo=noo+nrepb1;

 elseif finalstrOri(i)=="]"
 finalstr(noo)="]";
 noo=noo+nrepb2;

 elseif  finalstrOri(i)=="+"
 finalstr(noo)="+";
 noo=noo+nrepp;

 elseif finalstrOri(i)=="-"
 finalstr(noo)="-";
 noo=noo+nrepn;

  elseif finalstrOri(i)=="U"
 finalstr(noo)="U";
 noo=noo+nrepm;


endif

endfor
finalstrOri=finalstr;
count=count+1;
fprintf("\n")
fprintf("Rewrite Number %i is %s \n" , count, finalstr)
length(finalstr)
endfor
