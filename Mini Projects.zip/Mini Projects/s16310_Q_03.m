% rewrite and drawing the graph

clear all
clc
n = 7;
fprintf("\n")
count=0 ;% To count the no of rewrites and print the answer. Not necessary.

W0=["X"]
%axioms
repF="FF" % change of F
repx="F++X--F-X++X-UFFU" %  Change of X
repb1="["; % change of [
repb2="]"; % change of ]
repp="+";  % change of +
repn="-";  % change of -
repm="U";  % change of U

%length of the strings of axioms
nrep=length(repF);
Mrep=length(repx);
nrepb1=length(repb1);
nrepb2=length(repb2);
nrepp=length(repp);
nrepn=length(repn);
nrepm=length(repm);

% Definig the final outputs
finalstr=W0;
% To store the original string of the particular rewrite
finalstrOri=W0;

for j=1:n
k=length(finalstr); % length of the string
noo=1; % To count the place of the string that should be replaced.
for i=1:k

if finalstrOri(i)=="F"
 finalstr(noo:noo+nrep-1)="FF"; % noo:noo+nrep-1 is to show the number of places the string should be replaced.
  noo=noo+nrep; % to count the place of the string.

 elseif finalstrOri(i)=="X"

 finalstr(noo:noo+Mrep-1)="F++X--F-X++X-UFFU";
 noo=noo+Mrep;
 elseif finalstrOri(i)=="["
 finalstr(noo)="[";
 noo=noo+nrepb1;

 elseif finalstrOri(i)=="]"
 finalstr(noo)="]";
 noo=noo+nrepb2;

 elseif  finalstrOri(i)=="+"
 finalstr(noo)="+";
 noo=noo+nrepp;

 elseif finalstrOri(i)=="-"
 finalstr(noo)="-";
 noo=noo+nrepn;

  elseif finalstrOri(i)=="U"
 finalstr(noo)="U";
 noo=noo+nrepm;


endif

endfor
finalstrOri=finalstr;
count=count+1;
fprintf("\n")
fprintf("Rewrite Number %i is %s \n" , count, finalstr)
length(finalstr)
endfor

fprintf("\n")
fprintf("\n")
fprintf("\n")
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
         %Graph%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
[n2 m2] = size(finalstr);
ang = pi/2;
a = ones(1,m2)*ang; %Assigns a(1)= pi/2 the initial angle
x = zeros(1,m2);
y = zeros(1,m2);

d = 1 ;

delta=pi/12 ;

%To enter the symbols.

w= finalstr;

printf("%s\n",w);
fprintf("\n")
fprintf("\n")

M = zeros(1,3); % To store the values of angle

for i = 1:m2
  if w(i) == "F"
    x(i+1) = x(i)+cos(a(i))*d;
    y(i+1)= y(i)+sin(a(i))*d;
    a(i+1)=a(i);
  endif

  if w(i)=="+"
    a(i+1)=a(i)+ delta;
    x(i+1)=x(i);
    y(i+1)=y(i);
  endif

  if w(i) == "-"
    a(i+1)=a(i)- delta;
    x(i+1)=x(i);
    y(i+1)=y(i);
  endif

   if w(i) == "["

    a(i+1)= a(i);
    x(i+1)= x(i);
    y(i+1)=y(i);
    M = [M ; a(i+1) x(i+1) y(i+1)];

  endif

  if w(i) == "]"

    a(i+1) = M(end,1); % retrives the points of last saved in M matrix
    x(i+1) = M(end,2);
    y(i+1) = M(end,3);
    M(end,:)=[]; % Deletion of the used points
  endif
  if w(i) == "X"
    a(i+1)= a(i);
    x(i+1)= x(i);
    y(i+1)=y(i);


  endif
  if w(i) == "U"
    a(i+1)=a(i)-deg2rad(180);
    x(i+1)=x(i);
    y(i+1)=y(i);
  endif
endfor

%disp("   angle       x          y")
%[a' x' y']
%length(finalstr)


plot(x,y,"color","red")
title("Turtle Graph")
xlabel("x")
ylabel("y")

